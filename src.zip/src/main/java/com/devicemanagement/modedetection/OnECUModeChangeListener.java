package com.devicemanagement.modedetection;

public interface OnECUModeChangeListener {
	void onChange(int mode);
}

package com.devicemanagement.modedetection;

public interface OnEngineModeChangeListener {
	void onChange(int mode);
}
